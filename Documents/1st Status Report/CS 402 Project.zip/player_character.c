//player_character.c
//Jeff Skakun 10/24/14
//Class to maintain a player character's information
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "random_rolls.c"


//Limit name length to 10
#define MAX_NAME_LENGTH 11
#define MAX_FILE_NAME_LENGTH 15

struct character
{
   //Limit length of name to 10 characters
   char name[MAX_NAME_LENGTH];
   
   //Store current health of player
   int current_health;
   
   //Store max health of player
   int max_health;
   
   //Store player level
   int player_level;
   
   //Store lowest dungeon level reached
   int lowest_level;
   
   //Store current experience
   int current_experience;
   
   //Store experience required to reach next level
   int next_level_experience;
   
   //Store damage die (ex. d6) Do I need to increase like monsters?
   int damage_die;
   
   //Store damage modifier (+1)
   int damage_modifier;
   
   //Store number of rooms explored
   int rooms_explored;
   
   //Store number of monsters killed
   int monsters_killed;
};

//Function to create a new player
struct character* create_character();

//Function to save a character to file
//Creates a text file with the name of the character
void save_character(struct character *player);

//Function to load a character from file
//Will return a null pointer if character failed to load
struct character* load_character();

//Function to increase the player to the next level
void increase_character_level(struct character *player);

//Function to display basic character information
void print_full_character(struct character *player);

//Function to display name, level, health, and experience
void print_level_info(struct character *player);

//Function to modify the current health of character
//Make it an inline function?
void modify_health(struct character *player, int health_change);

//Function to modify the current player experience
//Will call function to increase player level if current experience
//exceeds next_level_experience
void modify_experience(struct character *player, int experience_change);

//Function to set the lowest dungeon level reached by player
//void lowest_dungeon_level(struct character player, int level);


main()
{
   struct character *player,*player2;
   
   int x,y;
   for(x=1;x<=10;x++)
   {
      printf("\n\nPlayer level %d:",x);
      player=create_character();
      
      for(y=1;y<x;y++)
         increase_character_level(player);
         
      print_full_character(player);
   }
   
   save_character(player);
   
   printf("\n\n");
   
   player2=load_character();
   
   printf("\n\nLOADING:\n");
   
   print_full_character(player2);
   
   /*
   player=create_character();
   
   print_full_character(player);
   
   save_character(player);
   
   player2=load_character();
   
   increase_character_level(player2);
   
   print_full_character(player2);
   
   
   modify_health(player,-10);
   
   printf("\n");
   
   print_full_character(player);
   
   modify_health(player,15);
   
   printf("\n");
   
   print_full_character(player);
   
   modify_experience(player,20);
   
   printf("\n");
   
   print_full_character(player);
   
   modify_experience(player,20);
   
   printf("\n");
   
   print_full_character(player);
   
   printf("\n");
   
   print_level_info(player);
   */
}

//Function to create a new player
struct character* create_character()
{
   //Initialize variables
   struct character *player;

   player=malloc(sizeof(struct character));
   
   //Input name
   //printf("Enter name (10 char maximum): ");
   //scanf("%s",player->name);
   strcpy(player->name,"CHANGEBACK");
   
   //Set initial current and max health to 20
   player->max_health=20;
   player->current_health=20;
   
   //Set player level to 1
   player->player_level=1;
   
   //Set lowest dungeon level reached to 1
   player->lowest_level=1;
   
   //Set player current experience to 0
   player->current_experience=0;
   
   //Set player experience to next level
   player->next_level_experience=25;
   
   //Set player damage die
   player->damage_die=6;
   
   //Set player damage modifier
   player->damage_modifier=0;
   
   //Set number of rooms explored to 0
   player->rooms_explored=0;
   
   //Set number of monsters killed to 0
   player->monsters_killed=0;
   
   //Player is set to level 1, return player
   return player;
}

//Function to display basic character information
void print_full_character(struct character *player)
{
   printf("\nPlayer name:          %s",player->name);
   printf("\nPlayer level:         %d",player->player_level);
   printf("\nCurrent hp:           %d/%d",player->current_health,player->max_health);
   printf("\nCurrent Experience:   %d/%d",player->current_experience,player->next_level_experience);
   printf("\nPlayer damage:        d%d+%d",player->damage_die,player->damage_modifier);
   printf("\nLowest level reached: %d",player->lowest_level);
   printf("\nRooms explored:       %d",player->rooms_explored);
   printf("\nMonsters killed:      %d",player->monsters_killed);
}

//Function to display name, level, health, and experience
void print_level_info(struct character *player)
{
   printf("\nPlayer name:          %s",player->name);
   printf("\nPlayer level:         %d",player->player_level);
   printf("\nCurrent hp:           %d/%d",player->current_health,player->max_health);
   printf("\nCurrent Experience:   %d/%d",player->current_experience,player->next_level_experience);
}

//Function to increase the player to the next level
void increase_character_level(struct character *player)
{
   //Increase player level by 1
   player->player_level++;
   
   //Increase player max hp and set current health equal to max (For now by a flat amount)
   player->max_health+=10;
   player->current_health=player->max_health;
   
   //Determine if there is any overflow experience
   int overflow_exp=player->current_experience - player->next_level_experience;
   
   //Reset player current exeperience to 0 and add back any overflow
   if(overflow_exp<0)
      player->current_experience=0;
   else
      player->current_experience=overflow_exp;
   
   //Set next level experience to new value (For now setting equal to 2x old value)
   player->next_level_experience+=25;
   
   //Not sure about damage die - for now won't change
   //Increase damage modifier by 1 every 2 levels
   if((player->player_level)%2==0)
      player->damage_modifier++;
}

//Function to modify the current health of character
//health_change is negative for damage taken
//health_change is positive for damage healed
void modify_health(struct character *player, int health_change)
{
   //Change current_health
   player->current_health+=health_change;
   
   //Check if current_health > max_health
   //Player can't have more than max_health
   if(player->current_health>player->max_health)
      player->current_health=player->max_health;
}

//Function to modify the current player experience
//Will call function to increase player level if current experience
//exceeds next_level_experience
void modify_experience(struct character *player, int experience_change)
{
   //Change current_experience
   player->current_experience+=experience_change;
   
   //Check to see player has leveled
   if(player->current_experience>player->next_level_experience)
      increase_character_level(player);
}

//Function to save a character to file
//Creates a .txt file in the same directory.
void save_character(struct character *player)
{
   //Code to add ".txt" to end of character name
   char file_name[MAX_FILE_NAME_LENGTH];
   
   //Copy character name to file name
   strcpy(file_name,player->name);   
   //Add .txt to end of file_name
   strcat(file_name,".txt");

   //Create a file with character name.txt
   FILE *outfile=fopen(file_name,"w");
   
   //Save character information to file
   fprintf(outfile,"%s\n",player->name);
   fprintf(outfile,"%d\n",player->current_health);
   fprintf(outfile,"%d\n",player->max_health);
   fprintf(outfile,"%d\n",player->player_level);
   fprintf(outfile,"%d\n",player->lowest_level);
   fprintf(outfile,"%d\n",player->current_experience);
   fprintf(outfile,"%d\n",player->next_level_experience);
   fprintf(outfile,"%d\n",player->damage_die);
   fprintf(outfile,"%d\n",player->damage_modifier);
   fprintf(outfile,"%d\n",player->rooms_explored);
   fprintf(outfile,"%d\n",player->monsters_killed);
   
   //Close file
   fclose(outfile);
}

//Function to load a character from file
struct character* load_character()
{
   //Initialize variables
   char file_name[MAX_FILE_NAME_LENGTH];
   FILE *infile;
   struct character *player=NULL;
   
   //Input name of file to load
   printf("\nName of character to load: ");
   scanf("%s",file_name);
   
   //Add .txt to end of file name
   strcat(file_name,".txt");
   
   //Open file
   if((infile=fopen(file_name,"r"))==NULL)
      printf("Cannot find file...");
   else
   {
      player=malloc(sizeof(struct character));
      fscanf(infile,"%s",player->name);
      fscanf(infile,"%d",&player->current_health);
      fscanf(infile,"%d",&player->max_health);
      fscanf(infile,"%d",&player->player_level);
      fscanf(infile,"%d",&player->lowest_level);
      fscanf(infile,"%d",&player->current_experience);
      fscanf(infile,"%d",&player->next_level_experience);
      fscanf(infile,"%d",&player->damage_die);
      fscanf(infile,"%d",&player->damage_modifier);
      fscanf(infile,"%d",&player->rooms_explored);
      fscanf(infile,"%d",&player->monsters_killed);
      
      printf("Character loaded.");
   }
   
   fclose(infile);
   
   return player;
}
   