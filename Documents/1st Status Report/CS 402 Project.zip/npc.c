//npc.c
//Jeff Skakun 10/27/14
//Class to contain and modify npc information
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "random_rolls.c"


#define MAX_MONSTER_NAME_LENGTH 21
#define NUM_OF_MONSTERS 13

//Hardwired list of monster names - potential to add more and/or move to file and import list
char MONSTER_NAMES[NUM_OF_MONSTERS][MAX_MONSTER_NAME_LENGTH]=
         {"Skeleton",
          "Ogre",
          "Orc",
          "Basilisk",
          "Cyclops",
          "Wisp",
          "Gargoyle",
          "Golem",
          "Troll",
          "Imp",
          "Minotaur",
          "Vampire",
          "Zombie"};

struct monster
{
   //Limit length of name to 10 characters
   char name[MAX_MONSTER_NAME_LENGTH];
   
   //Store current health of player
   int current_health;
   
   //Store max health of player
   int max_health;
   
   //Store player level
   int monster_level;
   
    //Store damage die (ex. d6)
   int damage_die;
   
   //Store damage modifier (+1)
   int damage_modifier;
   
   //Store amount of experience the monster is worth
   int experience;
};

//Function to create a new monster
struct monster* create_monster(int dungeon_level);

//Function to modify the current health of character
//Make it an inline function?
void modify_health(struct monster *npc, int health_change);

//Function to display basic monster information
void print_full_monster(struct monster *npc);

//Function to print Name and health of monster
void print_short_monster(struct monster *npc);

//Check if monster is dead
//Return -1 if monster is alive
//Return monster experience if dead
int monster_death(struct monster *npc);

main()
{
   srandom(time(NULL));
   /*
   int mon[NUM_OF_MONSTERS];
   int ctr;
   const int TOTAL=1000000;
   
   //Set all initial values to 0
   for(ctr=0;ctr<NUM_OF_MONSTERS;ctr++)
      mon[ctr]=0;
   
   //Randomly select a monster
   for(ctr=0;ctr<TOTAL;ctr++)
      mon[dice_roll(NUM_OF_MONSTERS)-1]++;
   
   double percent=0.0;
   for(ctr=0;ctr<NUM_OF_MONSTERS;ctr++)
   {
      percent=(mon[ctr]*100.0)/TOTAL;
      printf("%-10s %d%6.2f%%\n",MONSTER_NAMES[ctr],mon[ctr],percent);
   }
   */
   int ctr;
   
   for(ctr=0;ctr<10;ctr++)
   {
      printf("\n\nMonster #%d",(ctr+1));
      print_full_monster(create_monster((ctr+1)));
   }
   
   for(ctr=0;ctr<10;ctr++)
   {
      printf("\n\nMonster #%d",(ctr+1));
      print_short_monster(create_monster((ctr+1)));
   }
   printf("\n\n");
   struct monster *npc=create_monster(5);
   
   print_full_monster(npc);
   modify_health(npc,-5);
   printf("\n\n");
   if(monster_death(npc)<0)
      printf("NOT DEAD\n");
   else
      printf("OOPS");
      
   modify_health(npc,-50);
   
   if(monster_death(npc)<0)
      printf("OOPS");
   else
      printf("Monster dead - worth %d exp",monster_death(npc));
}

//Function to create a new monster
struct monster* create_monster(int dungeon_level)
{
   //Initialize variables
   struct monster *npc;
   
   npc=malloc(sizeof(struct monster));
   
   //Randomly pick name of monster
   strcpy(npc->name,MONSTER_NAMES[dice_roll(NUM_OF_MONSTERS)-1]);
   
   //Determine monster level
   npc->monster_level=dungeon_level;
   
   //Determine current and max health based on monster level
   npc->current_health=5+npc->monster_level;
   npc->max_health=5+npc->monster_level;
   
   //Determine experience worth
   npc->experience=5*npc->monster_level;
   
   //Determine damage die - add +1 to die level every 4 levels
   npc->damage_die=4+(npc->monster_level/4);
   
   //Store damage modifier (+1 every other level)
   npc->damage_modifier=0+(npc->monster_level/2);
   
   return npc;
}

//Function to display basic monster information
void print_full_monster(struct monster *npc)
{
   printf("\nMonster name:         %s",npc->name);
   printf("\nMonster level:        %d",npc->monster_level);
   printf("\nCurrent hp:           %d/%d",npc->current_health,npc->max_health);
   printf("\nExperience:           %d",npc->experience);
   printf("\nMonster damage:       d%d+%d",npc->damage_die,npc->damage_modifier);
}

//Function to print Name and health of monster
void print_short_monster(struct monster *npc)
{
   printf("\nMonster name:         %s",npc->name);
   printf("\nCurrent hp:           %d/%d",npc->current_health,npc->max_health);
}

//Function to modify the current health of character
//health_change is negative for damage taken
//health_change is positive for damage healed
void modify_health(struct monster *npc, int health_change)
{
   //Change current_health
   npc->current_health+=health_change;
   
   //Not sure if monsters will have a way to increase health yet
   //Check if current_health > max_health
   //Npc can't have more than max_health
   if(npc->current_health>npc->max_health)
      npc->current_health=npc->max_health;
}

//Check if monster is dead
//Return -1 if monster is alive
//Return monster experience if dead
int monster_death(struct monster *npc)
{
   //Check monster current health to see if it is dead (<=0)
   if(npc->current_health<=0)
      return npc->experience;
      
   //Monster is not dead
   return -1;
}