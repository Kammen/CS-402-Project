//encounters.c
//Jeff Skakun 10/29/14
//Class to determine random encounters on moving tiles
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "random_rolls.c"

//Needed?
#define NUM_OF_ENCOUNTERS 4

/*
   List of possible encounters and % of happening
      Nothing             35-70%
      Well (Full heal)    3%
      Artifact (Gain Exp) 2%
      Monster (Combat)    25-60%
*/

#define NOTHING_PERCENT .35
#define WELL_PERCENT .03
#define ARTIFACT_PERCENT .02
#define MONSTER_PERCENT .60
#define MAX_ROLL_NUMBER 1000

// Maybe return encounter # and let calling function deal??
//Function to determine which encounter is selected
//Returns 0 if non-combat
//Returns 1 if combat
//For now 0=nothing, 1=well, 2=artifact, 3=combat
int random_encounter();

main()
{
   srandom(time(NULL));
   int ctr;
   const int TOTAL=100000;
   int roll[4]={0,0,0,0};
   
   for(ctr=0;ctr<TOTAL;ctr++)
   {
      roll[random_encounter()]++;
   }
   
   double percent=0.0,tpercent=0.0;
   for(ctr=0;ctr<4;ctr++)
   {
      percent=(roll[ctr]*100.0)/TOTAL;
      printf("%d: %10d  %.2f%%\n",ctr,roll[ctr],percent);
      tpercent+=percent;
   }
   printf("Total: %14.2f%%\n",tpercent);
}

// Maybe return encounter # and let calling function deal??
//Function to determine which encounter is selected
//Returns 0 if non-combat 
//Returns 1 if combat
//For now 0=nothing, 1=well, 2=artifact, 3=combat
int random_encounter()
{
   //Calculate values for encounters
   int nothing=NOTHING_PERCENT*MAX_ROLL_NUMBER;
   int well=nothing+WELL_PERCENT*MAX_ROLL_NUMBER;
   int artifact=well+ARTIFACT_PERCENT*MAX_ROLL_NUMBER;
   int monster=artifact+MONSTER_PERCENT*MAX_ROLL_NUMBER;  
   
   //Determine the random number
   int rand_num=dice_roll(MAX_ROLL_NUMBER);
   
   //Let 1-550 be nothing
   if(rand_num<=nothing)
      //For now return 0
      return 0;
      
   //Let 551-580 be well
   else if(rand_num<=well)
      //For now return 1
      return 1;
      
   //Let 581-600 be artifact
   else if(rand_num<=artifact)
      //For now return 2
      return 2;
   
   //Let 601-1000 be combat
   else
      //For now return 3
      return 3;
}
