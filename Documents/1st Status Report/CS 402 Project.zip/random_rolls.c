//random_rolls.c
//Jeff Skakun 10/24/14
//Class to maintain random rolls
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//Make these functions inline??
//Function that returns a random number in a specific range
int rand_range(int min_n, int max_n)
{
    return random() % (max_n - min_n + 1) + min_n;
}

//Function that returns a random number from 1 to die
int dice_roll(int die)
{
   return random() % die +1;
}
/*
main()
{
   srand(time(NULL));
   srandom(time(NULL));
   int ctr,num;
   
   int dice[6]={0,0,0,0,0,0};
   const int TOTAL=10000000;
   
   for(ctr=0;ctr<TOTAL;ctr++)
   {
      dice[dice_roll(6)-1]++;
      //dice[rand_range(1,6)-1]++;
   }
   
   double percent=0.0,tpercent=0.0;
   for(ctr=0;ctr<6;ctr++)
   {
      percent=(dice[ctr]*100.0)/TOTAL;
      printf("%d: %d  %.2f%%\n",ctr,dice[ctr],percent);
      tpercent+=percent;
   }
   printf("Total:     %.2f%%\n",tpercent);
}*/